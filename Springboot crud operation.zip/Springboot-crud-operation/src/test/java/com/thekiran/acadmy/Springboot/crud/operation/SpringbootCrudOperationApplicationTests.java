package com.thekiran.acadmy.Springboot.crud.operation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
