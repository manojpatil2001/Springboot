package com.jbk.Demo.SpringBoot.IOC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringBootIocApplicationTests {

	@Test
	void contextLoads() {
	}

}
