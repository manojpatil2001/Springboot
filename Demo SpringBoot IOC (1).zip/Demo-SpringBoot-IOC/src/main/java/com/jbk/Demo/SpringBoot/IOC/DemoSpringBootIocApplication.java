package com.jbk.Demo.SpringBoot.IOC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringBootIocApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootIocApplication.class, args);
	}

}
