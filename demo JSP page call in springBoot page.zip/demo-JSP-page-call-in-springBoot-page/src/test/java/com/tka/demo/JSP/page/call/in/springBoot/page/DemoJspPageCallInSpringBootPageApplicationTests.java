package com.tka.demo.JSP.page.call.in.springBoot.page;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJspPageCallInSpringBootPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
