package com.tka.demo.JSP.page.call.in.springBoot.page;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJspPageCallInSpringBootPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoJspPageCallInSpringBootPageApplication.class, args);
	}

}
