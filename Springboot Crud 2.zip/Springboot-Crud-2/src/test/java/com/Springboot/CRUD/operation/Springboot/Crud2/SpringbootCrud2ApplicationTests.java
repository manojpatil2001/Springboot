package com.Springboot.CRUD.operation.Springboot.Crud2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrud2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
